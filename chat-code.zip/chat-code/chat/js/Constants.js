(function(win){
	win.Constants = {};
	win.Constants.serverPath = "http://10.203.62.112:3000/chat/";	
})(window);